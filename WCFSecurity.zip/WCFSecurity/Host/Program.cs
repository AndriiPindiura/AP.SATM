﻿#region Disclaimer
// THIS SOFTWARE COMES "AS IS", WITH NO WARRANTIES.  THIS
// MEANS NO EXPRESS, IMPLIED OR STATUTORY WARRANTY, INCLUDING
// WITHOUT LIMITATION, WARRANTIES OF MERCHANTABILITY OR FITNESS
// FOR A PARTICULAR PURPOSE OR ANY WARRANTY OF TITLE OR
// NON-INFRINGEMENT.
//
// MICROSOFT WILL NOT BE LIABLE FOR ANY DAMAGES RELATED TO
// THE SOFTWARE, INCLUDING DIRECT, INDIRECT, SPECIAL,
// CONSEQUENTIAL OR INCIDENTAL DAMAGES, TO THE MAXIMUM EXTENT
// THE LAW PERMITS, NO MATTER WHAT LEGAL THEORY IT IS
// BASED ON.
#endregion

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using Services.Authentication.Services;
using System.Security.Cryptography.X509Certificates;

namespace Host
{
 class Program
 {
  static void Main(string[] args)
  {
   ServiceHost host = new ServiceHost(typeof(AuthenticationSimpleService));
   X509Certificate2 cert =  host.Credentials.ServiceCertificate.Certificate;
   host.Open();
   Console.ReadLine();
   host.Close();
  }
 }
}
