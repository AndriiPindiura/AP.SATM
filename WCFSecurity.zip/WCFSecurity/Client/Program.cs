﻿#region Disclaimer
// THIS SOFTWARE COMES "AS IS", WITH NO WARRANTIES.  THIS
// MEANS NO EXPRESS, IMPLIED OR STATUTORY WARRANTY, INCLUDING
// WITHOUT LIMITATION, WARRANTIES OF MERCHANTABILITY OR FITNESS
// FOR A PARTICULAR PURPOSE OR ANY WARRANTY OF TITLE OR
// NON-INFRINGEMENT.
//
// MICROSOFT WILL NOT BE LIABLE FOR ANY DAMAGES RELATED TO
// THE SOFTWARE, INCLUDING DIRECT, INDIRECT, SPECIAL,
// CONSEQUENTIAL OR INCIDENTAL DAMAGES, TO THE MAXIMUM EXTENT
// THE LAW PERMITS, NO MATTER WHAT LEGAL THEORY IT IS
// BASED ON.
#endregion

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.ServiceModel;
using Services.Authentication.ServiceContracts;

namespace Client
{
 class Program
 {
  static void Main(string[] args)
  {
   Thread.Sleep(1500);
   Run("TcpWithMessageSecurity");
   Run("WsHttpWithMessageSecurity");
   Run("wsHttpWithMessageSecurityNoSPNEGO");
   Console.ReadLine();
  }

  static void Run(string endpointConfigurationName)
  {
   Console.WriteLine("Press enter to invoke PrintMessage operation on the service 3 times with " + endpointConfigurationName + " endpoint configuration");
   Console.ReadLine();
   ChannelFactory<ISimpleService> factory =
    new ChannelFactory<ISimpleService>(endpointConfigurationName);
   factory.Credentials.UserName.UserName = "test1";
   factory.Credentials.UserName.Password = "1tset";

   ISimpleService proxy = factory.CreateChannel();
   proxy.PrintMessage("1");
   proxy.PrintMessage("2");
   proxy.PrintMessage("3");
   ((ICommunicationObject)proxy).Close();
  }
 }
}
