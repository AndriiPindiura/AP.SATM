THIS SOFTWARE COMES "AS IS", WITH NO WARRANTIES.  THIS
MEANS NO EXPRESS, IMPLIED OR STATUTORY WARRANTY, INCLUDING
WITHOUT LIMITATION, WARRANTIES OF MERCHANTABILITY OR FITNESS
FOR A PARTICULAR PURPOSE OR ANY WARRANTY OF TITLE OR
NON-INFRINGEMENT.

MICROSOFT WILL NOT BE LIABLE FOR ANY DAMAGES RELATED TO
THE SOFTWARE, INCLUDING DIRECT, INDIRECT, SPECIAL,
CONSEQUENTIAL OR INCIDENTAL DAMAGES, TO THE MAXIMUM EXTENT
THE LAW PERMITS, NO MATTER WHAT LEGAL THEORY IT IS
BASED ON.

Before being able to run the sample, follow the steps below:
- Check my blog for the latest version: http://blogs.msdn.com/pedram 
- Create a certificate (http://msdn2.microsoft.com/en-us/library/ms733813.aspx)
- Modify the serviveCertificate elements defined in both client and service App.config files to reference your new certificate (you may decide to change the FindType as well)
- Specify a correct identity DNS value for the client endpoints

