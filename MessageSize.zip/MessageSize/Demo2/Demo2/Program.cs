﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using demo2;
using System.ServiceModel.Description;
using System.Threading;
using System.IO;
using System.ServiceModel.Dispatcher;
using System.ServiceModel.Channels;
using System.Xml;
using System.Reflection;
using Microsoft.ServiceModel.Samples;


namespace Demo2
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                RunService();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }

            Console.ReadLine();

            CallClient("binaryEndpoint");
            CallClient("gzipEndpoint");
            CallClient("textEndpoint");
            CallClient("mtomEndpoint");

        }

        private static void CallClient(string endpointName)
        {
            try
            {
                var cf = new ChannelFactory<ICalcultor>(endpointName);
                cf.Endpoint.Behaviors.Add(new InspectorEndpointBehavior());
                cf.Open();

                var proxy = cf.CreateChannel();

                //// Read all the bytes of the running process executable.
                //var input = File.ReadAllBytes(Assembly.GetExecutingAssembly().Location);
                //var s = input.Length;
                //proxy.Invert(input);

                proxy.Notify(Employee.GetEmployees(100)); // Get 100 employees.
            }
            catch (Exception e)
            {
                ClientOut(e.ToString());
            }

        }

        private static void RunService()
        {
            ServiceHost host = new ServiceHost(typeof(Calculator));

            host.Open();

            var sc = host.Description.Behaviors.Find<ServiceThrottlingBehavior>();


            ServerOut("Service ready!");
            foreach (ServiceEndpoint ep in host.Description.Endpoints)
                ServerOut(ep.Address.Uri.ToString());
        }


        private static void ClientOut(string p)
        {
            WriteInColor(p, ConsoleColor.Green);
        }

        private static void ServerOut(string p)
        {
            WriteInColor(p, ConsoleColor.Magenta);
        }

        private static void WriteInColor(string p, ConsoleColor color)
        {
            var orignal = Console.ForegroundColor;
            Console.ForegroundColor = color;
            Console.WriteLine(p);
            Console.ForegroundColor = orignal;
        }

    }


    public class InspectorEndpointBehavior : IEndpointBehavior
    {
        #region IEndpointBehavior Members

        public void AddBindingParameters(ServiceEndpoint endpoint, System.ServiceModel.Channels.BindingParameterCollection bindingParameters)   {   }

        public void ApplyClientBehavior(ServiceEndpoint endpoint, System.ServiceModel.Dispatcher.ClientRuntime clientRuntime)     {

            var encoding = endpoint.Binding.CreateBindingElements().Find<MessageEncodingBindingElement>() as GZipMessageEncodingBindingElement;

            clientRuntime.MessageInspectors.Add(new MessageSizeInspector(encoding));
        }

        public void ApplyDispatchBehavior(ServiceEndpoint endpoint, System.ServiceModel.Dispatcher.EndpointDispatcher endpointDispatcher)        {    }

        public void Validate(ServiceEndpoint endpoint)      {       }

        #endregion
    }

    public class MessageSizeInspector : IClientMessageInspector
    {
        GZipMessageEncodingBindingElement gzipEncoding;
        public MessageSizeInspector(GZipMessageEncodingBindingElement gzipEncoding)
        {
            this.gzipEncoding = gzipEncoding;
        }
        
        #region IClientMessageInspector Members

        public void AfterReceiveReply(ref System.ServiceModel.Channels.Message reply, object correlationState)
        {

        }

        public object BeforeSendRequest(ref System.ServiceModel.Channels.Message request, IClientChannel channel)
        {
            var mb = request.CreateBufferedCopy(int.MaxValue);

            request = mb.CreateMessage();

            var ms = new MemoryStream();
            // Dump message size based on text encoder.
            //using (var memWriter = XmlDictionaryWriter.CreateTextWriter(ms))
            //{
            //    mb.CreateMessage().WriteMessage(memWriter);
            //    memWriter.Flush();
            //    Console.WriteLine("Message size using text encoder {0}", ms.Position);
            //}

            //ms = new MemoryStream(); 

            if (gzipEncoding != null)
            {
                var encoder = gzipEncoding.CreateMessageEncoderFactory().CreateSessionEncoder();
                encoder.WriteMessage(mb.CreateMessage(), ms);

                Console.WriteLine("GZip encoded message size {0}", ms.Position);
            }
            else // just wrap the message - and wrapper will do the trick.
                request = new WrappingMessage(request);
            
            return null;
        }

        #endregion
    }


    public class WrappingMessage : Message
    {
        Message innerMsg;
        MessageBuffer msgBuffer;

        public WrappingMessage(Message inner)
        {
            this.innerMsg = inner;

            msgBuffer = innerMsg.CreateBufferedCopy(int.MaxValue);
            innerMsg = msgBuffer.CreateMessage();
        }
        public override MessageHeaders Headers
        {
            get { return innerMsg.Headers; }
        }

        protected override void OnWriteBodyContents(XmlDictionaryWriter writer)
        {
            innerMsg.WriteBodyContents(writer);
        }

        public override MessageProperties Properties
        {
            get { return innerMsg.Properties; }
        }

        public override MessageVersion Version
        {
            get { return innerMsg.Version; }
        }

        protected override void OnWriteMessage(XmlDictionaryWriter writer)
        {
            // write message to the actual encoder....
            base.OnWriteMessage(writer);
            writer.Flush();

            // write message to MemoryStream to get it's size.
            var copy = msgBuffer.CreateMessage();
            DumpEncoderSize(writer, copy);
        }

        private static void DumpEncoderSize(System.Xml.XmlDictionaryWriter writer, Message copy)
        {
            var ms = new MemoryStream();

            string configuredEncoder = string.Empty;
            if (writer is IXmlTextWriterInitializer)
            {
                var w = (IXmlTextWriterInitializer)writer;
                w.SetOutput(ms, Encoding.UTF8, true);
                configuredEncoder = "Text";
            }
            else if (writer is IXmlMtomWriterInitializer)
            {
                var w = (IXmlMtomWriterInitializer)writer;
                w.SetOutput(ms, Encoding.UTF8, int.MaxValue, "", null, null, true, false);
                configuredEncoder = "MTOM";
            }
            else if (writer is IXmlBinaryWriterInitializer)
            {
                var w = (IXmlBinaryWriterInitializer)writer;
                w.SetOutput(ms, null, null, false);
                configuredEncoder = "Binary";
            }
            
            copy.WriteMessage(writer);
            writer.Flush();
            var size = ms.Position;

            Console.WriteLine("Message size using configured ({1}) encoder {0}",  size,configuredEncoder);
        }
    
    }

}
