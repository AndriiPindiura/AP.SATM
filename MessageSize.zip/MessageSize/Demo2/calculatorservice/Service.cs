﻿using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Threading;
using System;
using System.Runtime.Serialization;


namespace demo2
{

    [DataContract]
    public class Employee
    {
        public Employee()
        {
            Image = new byte[new Random().Next(500)];
            new Random().NextBytes(Image);
        }
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public string Email { get; set; }
        [DataMember]
        public string Id { get; set; }
        [DataMember]
        public byte[] Image { get; set; }

        public static Employee[] GetEmployees(int count)
        {
            var emp = new Employee[count];
            for (int i = 0; i < count; i++)
            {
                emp[i] = new Employee()
                {
                    Email = string.Format("email{0}@hotmail.com", count + 1),
                    Id = string.Format("Emp{0}", count + 1),
                    Name = string.Format("John{0}", count + 1)
                };
            }

            return emp;
        }
    }


    [ServiceContract]
    public interface ICalcultor
    {
        [OperationContract]
        int Add(int a, int b);
        [OperationContract]
        bool Notify(Employee[] employees);

        [OperationContract]
        byte[] Invert(byte[] input);




    }

    [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerCall, AddressFilterMode=AddressFilterMode.Prefix)]
    public class Calculator : ICalcultor
    {
        #region ICalcultor Members

        private int count = 0;

        public int Add(int a, int b)
        {
            System.Console.WriteLine(this.GetHashCode());
            System.Console.WriteLine(++count);

       
     
            return a + b;
        }



        public byte[] Invert(byte[] input)
        {
            Array.Reverse(input);

            return input;
        }

        

        #endregion

        #region ICalcultor Members


        public bool Notify(Employee[] employees)
        {
            return true;
        }

        #endregion
    }
}